"""
Settings Configuration Module
Manages application settings and configuration.
"""

import os
import yaml
import logging
from pathlib import Path
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)


class Settings:
    """Application settings manager."""
    
    def __init__(self, config_file: Optional[str] = None):
        """Initialize settings with default values."""
        # Default settings
        self.defaults = {
            # Voice Interface Settings
            'speech_rate': 150,  # Words per minute
            'speech_volume': 0.8,  # Volume level (0.0 to 1.0)
            'speech_language': 'en-US',
            'microphone_timeout': 5,  # Seconds to wait for speech
            'phrase_timeout': 2,  # Seconds for phrase completion
            
            # Navigation Settings
            'default_location': 'Entrance',
            'step_size': 2,  # Steps per unit distance
            'navigation_precision': 'moderate',  # 'high', 'moderate', 'low'
            
            # Product Search Settings
            'max_search_results': 10,
            'search_confidence_threshold': 0.5,
            'suggest_alternatives': True,
            
            # Audio Settings
            'enable_sound_feedback': True,
            'beep_on_recognition': False,
            'audio_device_index': None,  # None for default
            
            # Accessibility Settings
            'verbose_descriptions': True,
            'repeat_instructions': False,
            'confirmation_required': False,
            
            # AI Settings
            'openai_api_key': None,
            'anthropic_api_key': None,
            'ai_model': 'gpt-3.5-turbo',
            'max_ai_response_length': 200,
            
            # Store Settings
            'store_layout_file': 'data/store_layouts/default_layout.json',
            'products_file': 'data/products.json',
            'store_name': 'Generic Supermarket',
            
            # Logging Settings
            'log_level': 'INFO',
            'log_file': 'logs/navigator.log',
            'enable_debug_mode': False,
            
            # Performance Settings
            'cache_enabled': True,
            'cache_size': 100,
            'preload_data': True,
        }
        
        # Current settings (start with defaults)
        self._settings = self.defaults.copy()
        
        # Load configuration file if provided
        if config_file:
            self.load_config(config_file)
        else:
            # Try to load default config files
            self._load_default_configs()
        
        # Override with environment variables
        self._load_environment_variables()
        
        logger.info("Settings initialized")
    
    def _load_default_configs(self):
        """Load configuration from default locations."""
        config_files = [
            'config.yaml',
            'config/config.yaml',
            Path.home() / '.supermarket-navigator' / 'config.yaml'
        ]
        
        for config_file in config_files:
            if Path(config_file).exists():
                logger.info(f"Loading configuration from {config_file}")
                self.load_config(str(config_file))
                break
    
    def load_config(self, config_file: str):
        """Load configuration from a YAML file."""
        try:
            config_path = Path(config_file)
            if config_path.exists():
                with open(config_path, 'r') as f:
                    config_data = yaml.safe_load(f)
                    if config_data:
                        self._update_settings(config_data)
                        logger.info(f"Configuration loaded from {config_file}")
            else:
                logger.warning(f"Configuration file not found: {config_file}")
        except Exception as e:
            logger.error(f"Error loading configuration file {config_file}: {e}")
    
    def _update_settings(self, config_data: Dict[str, Any]):
        """Update settings with values from configuration data."""
        for key, value in config_data.items():
            if key in self.defaults:
                self._settings[key] = value
                logger.debug(f"Setting {key} = {value}")
            else:
                logger.warning(f"Unknown configuration key: {key}")
    
    def _load_environment_variables(self):
        """Load settings from environment variables."""
        env_mapping = {
            'NAVIGATOR_SPEECH_RATE': 'speech_rate',
            'NAVIGATOR_SPEECH_VOLUME': 'speech_volume',
            'NAVIGATOR_LOG_LEVEL': 'log_level',
            'NAVIGATOR_STORE_NAME': 'store_name',
            'OPENAI_API_KEY': 'openai_api_key',
            'ANTHROPIC_API_KEY': 'anthropic_api_key',
            'NAVIGATOR_DEBUG': 'enable_debug_mode',
        }
        
        for env_var, setting_key in env_mapping.items():
            value = os.getenv(env_var)
            if value is not None:
                # Convert string values to appropriate types
                converted_value = self._convert_env_value(value, setting_key)
                self._settings[setting_key] = converted_value
                logger.debug(f"Environment variable {env_var} set {setting_key} = {converted_value}")
    
    def _convert_env_value(self, value: str, setting_key: str) -> Any:
        """Convert environment variable string to appropriate type."""
        # Boolean values
        if setting_key in ['enable_sound_feedback', 'beep_on_recognition', 'verbose_descriptions', 
                          'repeat_instructions', 'confirmation_required', 'cache_enabled', 'preload_data', 'enable_debug_mode']:
            return value.lower() in ['true', '1', 'yes', 'on']
        
        # Integer values
        if setting_key in ['speech_rate', 'microphone_timeout', 'phrase_timeout', 'step_size', 
                          'max_search_results', 'cache_size', 'max_ai_response_length']:
            try:
                return int(value)
            except ValueError:
                logger.warning(f"Invalid integer value for {setting_key}: {value}")
                return self.defaults[setting_key]
        
        # Float values
        if setting_key in ['speech_volume', 'search_confidence_threshold']:
            try:
                return float(value)
            except ValueError:
                logger.warning(f"Invalid float value for {setting_key}: {value}")
                return self.defaults[setting_key]
        
        # String values (default)
        return value
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get a setting value."""
        return self._settings.get(key, default)
    
    def set(self, key: str, value: Any):
        """Set a setting value."""
        if key in self.defaults:
            self._settings[key] = value
            logger.debug(f"Setting {key} updated to {value}")
        else:
            logger.warning(f"Unknown setting key: {key}")
    
    def save_config(self, config_file: str):
        """Save current settings to a YAML file."""
        try:
            config_path = Path(config_file)
            config_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Only save non-default values
            config_to_save = {}
            for key, value in self._settings.items():
                if value != self.defaults[key]:
                    config_to_save[key] = value
            
            with open(config_path, 'w') as f:
                yaml.dump(config_to_save, f, default_flow_style=False)
            
            logger.info(f"Configuration saved to {config_file}")
        except Exception as e:
            logger.error(f"Error saving configuration to {config_file}: {e}")
    
    def reset_to_defaults(self):
        """Reset all settings to default values."""
        self._settings = self.defaults.copy()
        logger.info("Settings reset to defaults")
    
    def validate_settings(self) -> bool:
        """Validate current settings and return True if all are valid."""
        is_valid = True
        
        # Validate speech rate
        if not (50 <= self.speech_rate <= 300):
            logger.warning(f"Invalid speech_rate: {self.speech_rate}. Should be between 50-300.")
            is_valid = False
        
        # Validate speech volume
        if not (0.0 <= self.speech_volume <= 1.0):
            logger.warning(f"Invalid speech_volume: {self.speech_volume}. Should be between 0.0-1.0.")
            is_valid = False
        
        # Validate search confidence threshold
        if not (0.0 <= self.search_confidence_threshold <= 1.0):
            logger.warning(f"Invalid search_confidence_threshold: {self.search_confidence_threshold}. Should be between 0.0-1.0.")
            is_valid = False
        
        # Validate file paths
        if self.store_layout_file and not Path(self.store_layout_file).exists():
            logger.warning(f"Store layout file not found: {self.store_layout_file}")
        
        if self.products_file and not Path(self.products_file).exists():
            logger.warning(f"Products file not found: {self.products_file}")
        
        return is_valid
    
    def get_all_settings(self) -> Dict[str, Any]:
        """Get all current settings as a dictionary."""
        return self._settings.copy()
    
    # Convenience properties for commonly used settings
    @property
    def speech_rate(self) -> int:
        return self._settings['speech_rate']
    
    @property
    def speech_volume(self) -> float:
        return self._settings['speech_volume']
    
    @property
    def speech_language(self) -> str:
        return self._settings['speech_language']
    
    @property
    def microphone_timeout(self) -> int:
        return self._settings['microphone_timeout']
    
    @property
    def phrase_timeout(self) -> int:
        return self._settings['phrase_timeout']
    
    @property
    def verbose_descriptions(self) -> bool:
        return self._settings['verbose_descriptions']
    
    @property
    def store_name(self) -> str:
        return self._settings['store_name']
    
    @property
    def search_confidence_threshold(self) -> float:
        return self._settings['search_confidence_threshold']
    
    @property
    def max_search_results(self) -> int:
        return self._settings['max_search_results']
    
    @property
    def store_layout_file(self) -> str:
        return self._settings['store_layout_file']
    
    @property
    def products_file(self) -> str:
        return self._settings['products_file']
